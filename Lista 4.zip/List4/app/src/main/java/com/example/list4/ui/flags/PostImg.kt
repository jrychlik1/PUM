package com.example.list4.ui.flags

data class PostImg(
    val name: String,
    val flag: String
)