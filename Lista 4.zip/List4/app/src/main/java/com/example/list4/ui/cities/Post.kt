package com.example.list4.ui.cities

data class Post(
    val name: String,
    val capital: String
)