package pl.edu.uwr.pum.recyclerviewwordlistjava;

public class Crime {
    private int mId;
    private String mTitle;
    private boolean mSolved;
    private String title2;

    public void setTitle2(String a) {
        this.title2 = a;
    }

    public String getTitle2(){
        return title2;
    }

    public void setTitle(String s) {
        this.mTitle = s;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setSolved(boolean b) {
        this.mSolved = b;
    }

    public boolean getSolved() { return mSolved; }

    public int getId() {
        return mId;
    }

    public void setId(int mId) { this.mId = mId; }

}
