package pl.edu.uwr.pum.recyclerviewwordlistjava;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CrimeList extends RecyclerView.Adapter<CrimeList.CrimeViewHolder> {

    private final CrimeLab crimeList;
    private final LayoutInflater inflater;

    public static final String EXTRA_MESSAGE = "pl.edu.uwr.pum.StudentCrime.MESSAGE";

    public CrimeList(Context context) {
        inflater = LayoutInflater.from(context);
        crimeList = CrimeLab.get(context);
    }

    public class CrimeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public final TextView crimeText;
        private final TextView crimeImage;
        final CrimeList adapter;
        public final Context context;

        public CrimeViewHolder(@NonNull View itemView, CrimeList adapter) {
            super(itemView);
            context = itemView.getContext();
            crimeText = itemView.findViewById(R.id.crime);
            crimeImage = itemView.findViewById(R.id.solved_image);
            this.adapter = adapter;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position = getLayoutPosition();
            Intent intent = new Intent(context, CrimeActivity.class);
            intent.putExtra(EXTRA_MESSAGE, position);
            context.startActivity(intent);
        }
    }

    @NonNull
    @Override
    public CrimeList.CrimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = inflater.inflate(R.layout.crime_list_item, parent, false);
        return new CrimeViewHolder(itemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull CrimeList.CrimeViewHolder holder, int position) {
        Crime currentCrime = crimeList.getCrime(position);
        holder.crimeText.setText(currentCrime.getTitle());
        if (currentCrime.getSolved()){
            holder.crimeImage.setVisibility(View.VISIBLE);
        }
        else{
            holder.crimeImage.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return crimeList.getSize();
    }
}
