package pl.edu.uwr.pum.recyclerviewwordlistjava;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

public class CrimeActivity extends AppCompatActivity {

    public static int id;
    private EditText editTitle;
    public CrimeLab crimeList;
    public static Crime currentCrime;
    private CheckBox editSolved;
    ViewPager2 viewPager2;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_fragment);

        viewPager2 = findViewById(R.id.detail_view_pager);

        Intent intent = getIntent();

        int currentCrimeId = intent.getIntExtra(CrimeList.EXTRA_MESSAGE, 0);
        crimeList = CrimeLab.get(this);
        crimeList.getCrime(currentCrimeId);

        DetailFragment adapter = new DetailFragment(this);
        viewPager2.setAdapter(adapter);

        viewPager2.setCurrentItem(currentCrimeId, false);


    }



}