package pl.edu.uwr.pum.recyclerviewwordlistjava;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DetailFragment extends RecyclerView.Adapter<DetailFragment.ViewHolder> {

    private Context context;
    private List<Crime> crimes;

    public DetailFragment(Context context) {
        crimes = CrimeLab.mCrimes;
        this.context = context;
    }


    @NonNull
    @Override
    public DetailFragment.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context)
                .inflate(R.layout.activity_crime, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Crime currentCrime = crimes.get(position);
//        holder.bind(currentCrime);
        holder.mTitle.setText(currentCrime.getTitle());;
        holder.title2.setText(currentCrime.getTitle2());;
        holder.mSolved.setChecked(currentCrime.getSolved());
        holder.mTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {
                if (!currentCrime.getTitle().equals(String.valueOf(s)))
                    currentCrime.setTitle(holder.mTitle.getText().toString());
            }
        });

        holder.title2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {
                if (!currentCrime.getTitle2().equals(String.valueOf(s)))
                    currentCrime.setTitle2(holder.title2.getText().toString());
            }
        });

        holder.mSolved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = ((CheckBox) v).isChecked();

                if (v.getId() == R.id.set_solved)
                    currentCrime.setSolved(checked);
            }
        });

    }

    @Override
    public int getItemCount() {
        return crimes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private EditText mTitle;
        private CheckBox mSolved;
        private EditText title2;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mTitle = itemView.findViewById(R.id.title_edit);
            mSolved = itemView.findViewById(R.id.set_solved);
            title2 = itemView.findViewById(R.id.title_edit3);
        }
        }
    }
